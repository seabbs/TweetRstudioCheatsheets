library(testthat)
library(rtweet)

test_check("rtweet")
