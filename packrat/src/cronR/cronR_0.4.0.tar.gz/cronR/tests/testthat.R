library(testthat)
library(cronR)
test_check("cronR")