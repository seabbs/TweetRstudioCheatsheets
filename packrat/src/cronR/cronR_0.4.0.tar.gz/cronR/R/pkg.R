#' @importFrom digest digest
#' @importFrom stats runif
#' @importFrom utils capture.output
NULL